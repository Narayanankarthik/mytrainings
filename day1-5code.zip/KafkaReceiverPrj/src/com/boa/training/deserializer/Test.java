package com.boa.training.deserializer;

public class Test {
public static void main(String[] args) {
	String s=null;
	
}
}
