package com.boa.training.deserializer;

import java.io.IOException;

import org.apache.kafka.common.serialization.Deserializer;

import com.boa.training.domain.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EmployeeDeserializer implements Deserializer<Employee> {

	private ObjectMapper mapper=new ObjectMapper();
	@Override
	public Employee deserialize(String topic, byte[] array) {
		// TODO Auto-generated method stub
		Employee e=null;
		try {
			e=mapper.readValue(array, Employee.class);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//System.out.println("checking for null"+(e==null));
		if(e==null) {
			e=new Employee();
		}
		return e;
	}

}
