package com.boa.training.deserializer;

import org.apache.kafka.common.serialization.Deserializer;

public class MyStringDeserializer  implements Deserializer<String>{

	@Override
	public String deserialize(String topic, byte[] args) {
		// TODO Auto-generated method stub
		System.out.println(args);
		System.out.println(new String(args));
		return new String(args);
	}

}
