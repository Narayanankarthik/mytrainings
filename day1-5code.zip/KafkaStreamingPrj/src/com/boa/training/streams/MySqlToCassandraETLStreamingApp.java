package com.boa.training.streams;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes.StringSerde;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;

import com.boa.training.domain.Employee;
import com.boa.training.serde.EmployeeSerde;

public class MySqlToCassandraETLStreamingApp {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties props=new Properties();
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, StringSerde.class.getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, EmployeeSerde.class.getName());
		props.put(StreamsConfig.APPLICATION_ID_CONFIG,"mysql-cassandra-etl-app");
		
		KafkaStreams streams=new KafkaStreams(createTopology(), props);
		streams.start();
		System.out.println("streaming started");
		try {
			Thread.sleep(10*60*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*finally {
		streams.close();
		}
		System.out.println("streaming stopped");*/
	}
	
	static Topology createTopology()
	{
		StreamsBuilder builder=new StreamsBuilder();
		String srcTopic="mysql-topic-employee";
		String targetTopic="cassandra-topic-employee";
		KStream<String, Employee> inputStream= builder.stream(srcTopic);
		KStream<String,Employee> transformedStream=inputStream.mapValues(e->{
			System.out.println("processing employee with id "+e.getId());
			Employee e1=new Employee();
			e1.setId(e.getId());
			e1.setName(e.getName());
			String designation=e.getDesignation();
			e1.setDesignation(designation);
			double salary=30000;
			if(designation.equals("Developer")) {
				salary=40000;
			}
			else if(designation.equals("Accountant")) {
				salary=35000;
			}
			else if(designation.equals("Architect")) {
				salary=80000;
			}
			e1.setSalary(salary);
			return e1;
		});
		transformedStream.to(targetTopic);
		return builder.build();
	}


}
