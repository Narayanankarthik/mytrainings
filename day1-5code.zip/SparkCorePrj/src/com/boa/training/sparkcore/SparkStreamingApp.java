package com.boa.training.sparkcore;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;

import scala.Tuple2;

public class SparkStreamingApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkConf conf=new SparkConf();
		conf.setAppName("streaming-app-with-kafka");
		conf.setMaster("local[*]");
		JavaStreamingContext streamingContext=new JavaStreamingContext(conf, Durations.seconds(60));
		
		Map<String, Object> props=new HashMap<>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, 
				StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, 
				StringDeserializer.class.getName());
		props.put(ConsumerConfig.GROUP_ID_CONFIG, 
				"group-1");
		
		List<String> topics=Collections.singletonList("test-sparkstream-topic");
		
		JavaInputDStream<ConsumerRecord<String, String>> dStream= KafkaUtils.createDirectStream(streamingContext,
				LocationStrategies.PreferConsistent(),
				ConsumerStrategies.Subscribe(topics, props));
		
		/*dStream.map(record->record.value()).flatMap(line->Arrays.asList(line.split(" ")).iterator())
		.mapToPair(word->new Tuple2<>(word, 1))
		.reduceByKey((x,y)->x+y).print();
		*/
		dStream.map(record->record.value()).flatMap(line->Arrays.asList(line.split(" ")).iterator())
		.mapToPair(word->new Tuple2<>(word, 1))
		.reduceByKey((x,y)->x+y).dstream().saveAsTextFiles("hdfs://localhost:9820/training/", "-wc");
		streamingContext.start();
		System.out.println("streaming started");
		try {
			Thread.sleep(10*60*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		streamingContext.stop();
		System.out.println("streaming stopped");
	}

}
