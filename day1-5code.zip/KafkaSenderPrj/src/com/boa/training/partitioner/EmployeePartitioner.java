package com.boa.training.partitioner;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import com.boa.training.domain.Employee;

public class EmployeePartitioner implements Partitioner {
	private Properties props=new Properties();
	@Override
	public void configure(Map<String, ?> env) {
		// TODO Auto-generated method stub
		try {
			FileInputStream fin=new FileInputStream("designation.properties");
			props.load(fin);
			fin.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		props=null;
	}

	@Override
	public int partition(String topic, Object key, byte[] keyBytes,
			Object value, byte[] valueBytes, Cluster cluster) {
		// TODO Auto-generated method stub
		int partition=4;
		Employee employee=(Employee)value;
		String designation=employee.getDesignation();
		String partitionNo=props.getProperty(designation);
		if(partitionNo!=null) {
			partition=Integer.parseInt(partitionNo);
		}
		return partition;
	}

}
